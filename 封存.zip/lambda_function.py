import psycopg2
from psycopg2.extras import RealDictCursor
import json

host = "database-1.c4alhaecwxce.us-east-1.rds.amazonaws.com"
username = "postgres"
password = "postgres"
database = "dbhw1"

conn = psycopg2.connect(
    host = host,
    database = database,
    user = username,
    password = password
)

def lambda_handler(event, context):
    cur = conn.cursor(cursor_factory = RealDictCursor)
    cur.execute("select * from country limit 1")
    results = cur.fetchall()
    json_result = json.dumps(results)
    # print(json_result)
    # return json_result
    return {
        'statusCode' : 200,
        'body' : json.dumps('Hello world')
    }



# lambda_handler('a','a')
